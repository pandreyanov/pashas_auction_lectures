# General Ideas

## Discovery and liquidity
Double auctions are often very large in scale and serve two important purposes, that are not immediately obvious: **price discovery** and **liquidity provision**.
- **liquidity provision** means that at any point in time, a buyer or a seller should be able to execute a transaction of any (reasonable) size without delays and disturbance to the market. Of course, the price of such transaction can be very large, but the point is that there should never be leftovers of grain rotting by the end of the day.
- **price discovery** means that the auction should signal a (presumably scalar) characteristic that reflects the true price of the asset and can be further used as a tool in derivative financial instruments and various contracts. This price should therefore be stable and reliable. 

Basically, in double auctions, we are mostly interested in the dissemination and revelation of private information and smooth absorbtion of supply and demand shocks. 








## Market clearing and formats

There are at least two main formats of a double auction: the **uniform-price** and the **pay-as-bid**. In both auctions, bidders reveal demand functions ($p$ as function of $q$ or vice versa) which are then aggregated to find the market clearing price. 

:::{important}
Let $q_i(p)$ be the demand function of player $i$, then **market clearing** means

$$ \sum_i q_i(p) = 0$$

which is the main equation that characterises the market. Of course, we could replace $0$ with $S$ - a static supply, or $S(p)$ - an increasing supply curve.
:::

 Assuming monotonicity of demands, there should be at most one solution $p^{\ast}$ to this equation, that is called a **wholesale** price (by practitioners), or a **market clearing** price (by academics), or a **stop-off** price (in an ascending format), depending on the context. The main difference is the calculation of payments.

:::{important}
In the **uniform-price** format, which is typically sealed-bid, the payment is the wholesale price times your demand.

$$t_i = p^{\ast} q_i(p)$$

In the **pay-as-bid** auction, which is typically ascending, the price climbs up (for farmers) and you get what yo demand at the running price.

$$dt_i = q_i(p) dp \quad \text{or} \quad t_i = \int^{p^{\ast}} q_i(p) dp$$

The price at which the price stops climbing in an ascending format is the **stop-off** price.
:::

Historically, the uniform-price version is somewhat easier to model so academics would use it to understand such markets even if the majority of auctions would be pay-as-bid.








## A toy model

Consider a single-shot model of a uniform-price double auction with $n$ agents, with quadratic utilities, which submit linear demand functions for a single divisible asset (good):

$$q_i(p) = a_i + b_i p$$

where $a_i, b_i$ are the coefficients, chosen by the agent. In other words, $(a_i, b_i)$ is the strategy of agent $i$.

:::{note}
Because utilities are quadratic, the first order condition is linear and so strategies will also be linear in equilibrium.
:::

As a first step we can write out the market clearing condition, assuming that all $b_i = b$ right away:

$$0 = \bar q = \bar a + b p$$
where the bar means average over all agents.

Assuming a quadratic utility, each agent maximizes

\begin{gather*}
\pi(q_i) = \theta_i q_i - \mu \frac{q_i^2}{2} - p q_i = \\
(\theta_i - p) q_i - \mu \frac{q_i^2}{2}
\end{gather*}

Hastily optimizing over $q_i$ we arrive at

$$ q_i = \mu^{-1} (\theta_i - p)$$

which looks a lot like the demand we were looking for, so we could, for example, argue that $a_i = \mu^{-1} \theta_i, b_i = -\mu^{-1}$ is the equilibrium of this model, and the wholesale price is equal to 

$$p^{\ast} = -\frac{\bar a}{b} = \bar \theta$$

Does this price make sense? Test Yourself

:::{dropdown} Imagine thеse are mills buying wheat. Let $a_i$ be the **negative endowment shock** of mill $i$, that is, a sudden dissapearance of $a_i$ units of wheat that should have been otherwise on balance. How would you interpret the wholesale price?
The wholesale price reflects the average demand for wheat in the economy.
:::
:::{dropdown} Imagine these are farmers selling wheat. How could you (as a researcher) make use of the wholesale price?
By looking at this price, we can predict the prices of other assets: flour, bread... those that use wheat as an input. We could also infer that this might have been a bad year for everyone so that other assets (rice, corn) could also increase in price.
:::







(double_auctions_market_power)=
## Market power

It turns out that the solution above is not the best you can come up with. The reason is that agents do not recognize their **market power** - the ability to influence the wholesale price. In other words, a rational player, if he is sufficiently large, would use a slightly different first order condition. See the difference below:

- without price impact: $\theta_i - \mu q = p$
- with price impact: $\theta_i - \mu q = p + \frac{\partial p}{\partial q} q = 0$

:::{important}
The partial derivative measures market power, that is, how much of a monopolist you are: 

$$\lambda_i(p) = \frac{\partial p^{\ast}}{\partial q}$$

In the literature it is often called Kyle's lambda, or **price impact**.
:::

Note that this time (assuming all lambdas are equal) we get

$$ q_i = (\mu + \lambda)^{-1}  (\theta_i - p)$$

which is different from what we saw in our first attempt. This time 
 $a_i = (\mu + \lambda)^{-1} \theta_i, b_i = - (\mu + \lambda)^{-1}$ and the wholesale price is again equal to 

$$p^{\ast} = -\frac{\bar a}{b} = \bar \theta.$$

Is this the end? Of course not, we have to actually find the lambda. For this we have to figure out how much does the equilibrium price change when any given $q_i$ changes.

:::{note}
The most natural way to find the **price impact** of agent $i$ is to ignore his demand completely and work with demands of other $n-1$ players and market clearing.
:::

Take the system of demands $d_i = q_i(p)$, $i = 1, \ldots, n$ and replace $d_i = q_i(p)$ with $\sum d_i = 0$. Solving this system requires some agility with negative indices ($\bar x_{-i}$ means average $x$ excluding $i$):

\begin{align*}
\theta_j - p & = (\mu + \lambda) q_j, \quad j \neq i \\
\bar \theta_{-i} - p & = (\mu + \lambda) \bar q_{-i} \\
\bar \theta_{-i} - p & = (\mu + \lambda) \frac{n \bar q - q_i}{n-1} \\
\bar \theta_{-i} - p & = - (\mu + \lambda) \frac{q_i}{n-1}
\end{align*}

What we found here is called a **residual demand**

$$ r_i(q) = \bar \theta_{-i} + (\mu + \lambda) \frac{q}{n-1} $
that is, a combined action of all other (excluding $i$) players. It is welded into the equilibrium and from the perspective of player $i$ it is as hard as stone.

:::{note} 
If every player plays linear demands, the **residual demand** is linear, and thus the best response is necessarily linear. However, there might be other, non-linear equilibria. 
:::

:::{note}
The **residual demand** for player $i$ should only contain characteristics of players $j \neq i$. If it contains an actual index $i$, you probably made a mistake.
:::

Finally, we can pull out the lambda:

$$ \lambda = \frac{\partial r_i(q)}{\partial q} = \frac{\mu + \lambda}{n-1}$$

Solving it is not hard. Test yourself.

:::{dropdown} Before solving, what would you think is the relationship between $\lambda$ and $n$?
Lambda is a measure of monopoly power and thus decreases in $n$.
:::
:::{dropdown} What is the value of $\lambda$ and $(\mu + \lambda)^{-1}$?
The answer is

$$ \lambda = \frac{\mu}{n-2}, \quad (\mu + \lambda)^{-1} = \frac{n-2}{n-1}\mu^{-1}$$
:::

Note that for $n = 2$ there is no trade as $\lambda$ explodes and $q_i$ becomes zero, which might seem a bit extreme. However, it is well known that bilateral negotiations very often fall apart, leading to status quo. That is because each party is trying to exercise their market power.

:::{dropdown} Did someone say "power"?
:::{image} ../\_assets/pics/unlimited-power.gif
:align: center
:width: 100%
:::


(double_auctions_interdependent)=
## Interdependent utilities

So far we managed to deal with market power (i.e. price impact, Kyle's lambda), but what about the informativeness of the price? To address this issue, we will further work on our toy model. To be precise, let
- each agent's utility be $U(\theta, q) = (\theta_i + \alpha \bar \theta_{-i})q - \frac{\mu}{2} q^2$

:::{important}
This type of model is called **interdependent utility** as agents types are mixed into other agents utilities. The idea is that once you hear that your neighbor values the asset you immediately value the asset as well, because you could sell it to him. However, the degree of interdependence ($\alpha$) should not be too large, otherwise the equilibrium will break down.
:::

Solving this model is not that much different, if you can handle the $\bar x_{-i}$ notation. Assume, just like before that the strategy (submitted demand function) is linear with the same slope $b$ and the price impact $\lambda$ is constant and also the same.

Let's first aggregate over all $j$ to find the wholesale price $p^{\ast} = (1+\alpha)\bar \theta$:

\begin{align*}
\theta_j + \alpha \bar \theta_{-j} - p & = (\mu + \lambda) q_j\\
\bar \theta + \sum_{j} \frac{\alpha \bar \theta_{-j}}{n} - p & = (\mu + \lambda) \bar q \\
\bar \theta + \alpha \bar \theta - p & = 0 \\
(1+\alpha)\bar \theta - p & = 0
\end{align*}

Test yourself:
:::{dropdown} When $\alpha>0$ can you come up with an interpretation of this phenomena?
When values are **interdependent**, shocks are echoed through the system making the price overreact.
:::

Now let's aggregate over all $j \neq i$ to find the residual demand:

\begin{align*}
\theta_j + \alpha \bar \theta_{-j} - p & = (\mu + \lambda) q_j, \quad j \neq i \\
\theta_j + \alpha \frac{n \bar \theta - \theta_j}{n-1} - p & = (\mu + \lambda) q_j, \quad j \neq i \\
\bar \theta_{-i} + \alpha \frac{n \bar \theta - \bar \theta_{-i}}{n-1} - p & = (\mu + \lambda) \bar q_{-i}\\
\bar \theta_{-i} + \alpha \frac{(n-2) \bar \theta_{-i} + \theta_i}{n-1} - p & = (\mu + \lambda) \frac{n \bar q - q_i}{n-1}\\
(1+\frac{n-2}{n-1}\alpha)\bar \theta_{-i} + \frac{\alpha}{n-1}\theta_i - p & = -(\mu + \lambda) \frac{q_i}{n-1}
\end{align*}

Soo... it is the same lambda as before?

:::{warning}
Actually no. This approach to $\lambda$ is not valid in the **interdependent utility** setting because $\theta_i$ sneaked in through the utilities. The true **residual curve** of agent $i$ should not depend on agent $i$ informationally, so we have to do more work.
:::

Let's fix this now by recalling the wholesale price formula:

\begin{align*}
(1+\alpha)\bar \theta & = p\\
(1+\alpha)\frac{(n-1)\bar \theta_{-i} + \theta_i}{n} & = p\\
(n-1)\bar \theta_{-i} + \theta_i & = \frac{n p}{(1+\alpha)}\\
\frac{n p}{(1+\alpha)} - (n-1)\bar \theta_{-i} & = \theta_i
\end{align*}

Now, in the last formula, we can eliminate $\theta_i$:

$$(1+\frac{n-2}{n-1}\alpha)\bar \theta_{-i} + \frac{\alpha}{n-1}(\frac{n p}{(1+\alpha)} - (n-1)\bar \theta_{-i}) - p = -(\mu + \lambda) \frac{q_i}{n-1}$$

And we can take the proper derivative to compute lambda:

$$ \lambda = \frac{\mu + \lambda}{n-1} / k, \quad k = (1-\frac{\alpha}{1+\alpha}\frac{n}{n-1})$$

This is clearly solvable in $\lambda$.

:::{code}
k, la, n, mu, al = symbols('k lambda n mu alpha')

k = al/(1+al)
k *= n/(n-1)
k = 1-k

sol1 = solve(la - (mu + la)/((n-1)*k), la)[0]

print('\lambda =', latex(sol1))
:::

$$ \lambda = \frac{\mu \left(\alpha + 1\right)}{- 2 \alpha + n - 2} $$





## Solution concepts

There are several solution concepts that can be applied in this framework:

- a **classic Bayes-Nash equilibrium** would hypothesise the (presumably linear) strategies of other players and establish a best response that yields the highest **average profit** of player $i$. Since it can be maximized pointwise over $\bar \theta_{-i}$ - the aggregate uncertainty of player $i$, there is a unique optimal strategy.
- an **ex-post equilibrium** would hypothesise the (presumably linear) strategies of other players and establish a best response that yields the highest **pointwise profit** of player $i$. That is, for every realization of $\theta$, player $i$ picks a best possible (scalar) demand and it matches his strategy. Since $\bar \theta_{-i}$ is a sufficient statistic for $\theta$, the same argument applies.
- a **rational expectations equilibrium** would hypothesise an equilibrium distribution of the public signal, in our case the wholesale price $p^{\ast}$, and establish a best response to it. This is the only solution concept that ignores the price impact, because player $i$ fails to recognize that part of the variation of $p^{\ast}$ is caused by his own actions. Otherwise, it is largely equivalent to Bayes-Nash.







## Surplus gain

If utilities are truly quadratic (another approach would be to derive them as a monotone transformation of ex-post CARA utilities) the  **surplus gain** can be measured by a sum of utilities of all agents, assuming that status quo has zero utility. The transfers would cancel out, but in our case it is actually better to keep them:

$$ \text{SG}= \mathbb{E} \sum_i [(\theta_i + \alpha \bar \theta_{-i}) q_i - \frac{\mu}{2} q_i^2 - p^{\ast} q_i] $$
where the equilibrium demands and price are

$$ q_i = (\mu + \lambda)^{-1} (\theta_i + \alpha \bar \theta_{-i} - p^{\ast}), \quad p^{\ast} = (1+\alpha) \bar \theta $$
putting these two together (ignore the price formula) we get

$$ \text{SG} = \mathbb{E} \sum_i [(\mu + \lambda - \frac{\mu}{2}) q_i^2] $$

Taking expectation and recognizing the symmetry

$$ \text{SG} = n (\mu + \lambda - \frac{\mu}{2}) \mathbb{E} q_i^2 $$

This can be relatively easily computed if we recall that $\mathbb{E} \theta_i \bar \theta_{-i} = 0$ and $\mathbb{E} (\bar \theta_{-i})^2 = \mathbb{E} \theta^2_i / (n-1)$. The answer will depend only on the second moment of the distribution of private type.

:::{code}
ti, tbarmi, tbar, qi = symbols('t_i tbar_{-i} tbar q_i')

tbar = ((n-1)*tbarmi + ti)/n
qi = (ti + al*tbarmi - (1+al)*tbar)/(mu+sol1)
expr = n*(mu+ sol1 - mu/2)*(qi**2)

sol2 = factor(expand(expr).subs(ti*tbarmi, 0).subs(tbarmi**2, ti**2/(n-1)))

print('\\text{SG} =', latex(sol2).replace('t_{i}^{2}',''), '\mathbb{E} \\theta_i^2')
:::

$$ \text{SG} = \frac{n  \left(- 2 \alpha + n - 2\right)}{2 \mu \left(n - 1\right)}\mathbb{E} \theta_i^2 > 0$$

Test yourself:
:::{dropdown} What can you infer from this formula?
Surplus gain is almost linear in n. It is also decreasing in $\alpha$.
:::

:::{dropdown} What happens when $\alpha$ is big and positive? Explain
Lambda becomes infinite and so there is no trade, no surplus gain.
:::







## Informational gain

To study information, we have to introduce some aggregate uncertainy, that is, an unknown parameter that can not be fully recovered even when all private types are known. To be precise, let
- each agent's utility be $U(\theta, q) = (\theta_i + \alpha \bar \theta_{-i})q - \frac{\mu}{2} q^2$
- each type $\theta_i$ is private but $\theta|\omega \sim \mathcal{N}(\omega I_n, \sigma^2 I_n)$
- where $\omega \sim \mathcal{N}(0, 1)$ is the unknown **fundamental value** and $\sigma$ is known

An alternative way to model this would be to say that agents receive noisy signals $\theta_i = \omega + \varepsilon_i + \delta$, where all components (fundamental value and both errors) are jointly and normally distributed. From this we can immediately infer that 

$$ \mathbb{V} \theta_i = 1 + \sigma^2, \quad \mathbb{V} \bar \theta = 1 + \sigma^2/n$$

:::{warning} 
Because $\theta$ are now correlated it is no longer true that $\mathbb{V} \bar \theta = \mathbb{V} \theta_i/n$.
:::

Typically at this point we would model the utility as expectation of $\omega$ conditional on $\theta_i, p^{\ast}$, but, for simplicity, we will keep the old utility intact.

Now, the informational content in this model can be measured by either MSE or Variance (Bias is known) of the fundamental value conditional on various informational sets available to us:

- full information: $V_1 = \mathbb{V}(\omega | \theta)$
- after the auction: $V_2 = \mathbb{V}(\omega | \theta_i, p^{\ast})$
- before the auction: $V_3 = \mathbb{V}(\omega | \theta_i)$

Clearly, we have that

$$V_1 <  V_2 < V_3$$

unless $p^{\ast}$ is somehow a sufficient statistic for $\mathbb{V}(\omega | \theta)$, in which case $V_1 = V_2$.

:::{important}
Conditional expectation of jointly normal random variables is linear in the conditioning set:

$$ \mathbb{V}(\omega | \theta) = c_1 \theta_1 + c_2 \theta_2 + \ldots + c_n \theta_n$$
and in the particular case where indexes can be permuted (symmetry of agents)

$$ \mathbb{V}(\omega | \theta) = n c \bar \theta, \quad c = c_i$$
which means that $\bar \theta$ would be a sufficient statistic.
:::

We can now measure the **informational gain** in the auction, that characterises the quality of price discovery:

$$ \text{IG} = V_3 - V_2 = \mathbb{V}(\omega | \theta_i) - \mathbb{V}(\omega | \theta_i, p^{\ast}) = \mathbb{V}(\omega | \theta_i) - \mathbb{V}(\omega | \bar \theta)$$

By the Gaussian Projection Theorem, 

$$\mathbb{V}(x|y) = \mathbb{V}(x) - \frac{\mathbb{C}^2(x,y)}{\mathbb{V}(y)}$$

thus

$$ \text{IG} = \frac{\mathbb{C}^2(\omega,\bar \theta)}{\mathbb{V}(\bar \theta)} - \frac{\mathbb{C}^2(\omega,\theta_i)}{\mathbb{V}(\theta_i)} = \frac{\mathbb{C}^2(\omega,\theta_i)}{\mathbb{V}(\theta_i)/n} - \frac{\mathbb{C}^2(\omega,\theta_i)}{\mathbb{V}(\theta_i)} = \frac{1}{1+\sigma^2/n} - \frac{1}{1+\sigma^2} > 0$$

:::{dropdown} What can you infer from this formula?
Information gain is increasing in $n$.
:::

