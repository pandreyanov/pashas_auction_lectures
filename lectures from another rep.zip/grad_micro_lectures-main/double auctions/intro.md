# Intro

We start with an informal definition of our main object of interest. Unlike classic auctions, a **double auction** is an auction format where both sellers and buyers compete for the allocation of a good or (possibly divisible) commodity. A typical example is a wholesale market of wheat in the US. There are farmers who want to sell and there are mills that want to buy. That is, there are (at least) two strategic sides, hence the **double** term.

We will briefly talk about the key concepts that are of interest in the double auctions environment, the difference in formats. We will then consider a toy model and talk about the possible solution concepts.

I draw the material from three types of assets

these books:
- Book: [Information and Learning in Markets](
https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/vives_book.pdf)
- Book: [Information Choice in Macroeconomics and Finance](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/veldcamp_book.pdf)

these dissertations:
- Dissertation: [Sergei Glebkin](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/glebkin_diss.pdf)
- Dissertation: [Paulo Coutihno](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/coutigno_diss.pdf)
- Another version: [Paulo Coutihno](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/coutigno_whenissued.pdf)
- Dissertation: [Dimitri Vayanos](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/vayanos_diss.pdf)

and these papers:
- [Continuous Auctions and Insider Trading, 1985](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/kyle_85_paper.pdf)
- [Informed Speculation with Imperfect Competition, 1989](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/kyle_89_paper.pdf)
- [Strategic Trading in a Dynamic Noisy Market, 2001](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/vayanos_main.pdf)
- [Liquidity and Asset Returns Under Asymmetric Information and Imperfect Competition, 2011](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/vayanos_protected.pdf)
- [Price Inference in Thin Markets, 2012](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/ECTA_paper.pdf)
- [Asset Prices and Liquidity with Market Power and Non-Gaussian Payoffs, 2020](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/glebkin_new.pdf)

and also all of [Marzena Rostek](https://www.ssc.wisc.edu/~mrostek/research) papers on decentralized markets.

Our main goal is to comprehend the modeling techniques and the questions that are being answered using those techniques.

I will also use a bit of python to solve stuff

:::{code}
from sympy import *
from sympy.solvers import solve
:::