# Advanced models

## Models with resale

We will consider a model with resale as in [Paulo Coutihno Dissertation](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double auctions/coutigno_diss.pdf), see Section 3.3.3 and Propositions 7 and 9 and also very similar to a model with a forward market (which is not the same as resale) as in [his another paper](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double auctions/coutigno_whenissued.pdf). Do not get confused because he turns market power on and off all the time. The building blocks of the model are:

- there are two stages: auction and resale, and markets clear in both
- $q_i^A$ is trader $i$'s position prior to resale
- $q_i$ is trader $i$'s position after resale
- $q_i^R = q_i - q^A_i$ is trader $i$'s adjustment during resale
- the prices in two stages are $p^A$ - **wholesale price** and $p^R$ - **resale price**
- utility is private type $U(q_i, \theta_i) = q_i \theta_i - \frac{\mu}{2} q_i^2$

:::{important}
We will solve the problem by **backwards induction**, that is, first we will consider the resale market, where the positions $q_i^A$ are already given and traders only ackquire additional $q_i^R$ at price $p^R$ up to their desired final position $q_i$. Then, we will consider the auction, where strategies $q_i^R(q_i^A, p^R)$ are already known.
:::

:::{warning}
For exposition, we will consider simplified versions with market power in only one of two stages. But the most interesting case would, of course, be market power in both stages.
:::

### Case 1: No market power in the wholesale

In the second stage, the optimization problem is:

\begin{gather*}
\max_{q_i} \theta_i q_i - \frac{\mu}{2}q_i^2 - p^R (q_i - q_i^A)\\
\theta_i - \mu q_i - p^R - (q_i - q_i^A) \frac{\partial p^R}{\partial q_i} = 0
\end{gather*}

Again, we hope that price impact in the second period is constant and so we call it $\lambda_1^R = \frac{\partial p^R}{\partial q_i}$.

$$ \theta_i - \mu q_i - p^R - (q_i - q_i^A) \lambda_1^R = 0 $$

A keen eye would notice that positions $q_i^A$ are absorbed into private types $\theta_i$

$$ (\theta_i + q_i^A \lambda_1^R) - p^R = (\mu + \lambda^R_1) q_i $$

This can be solved as a one-shot double auction.

:::{seealso}
We can also use the answers from the [toy model with market power](double_auctions_market_power)
:::

$$ p^R = \bar \theta, \quad \lambda_1^R = \frac{\mu}{n-2}, \quad q_i = (\lambda_1^R + \mu)^{-1}(\theta_i + q_i^A \lambda_1^R - p^R)$$

since $\bar q_i^A = 0$ by assumtion. Note that the resale price $p^R$ does not depend on the starting positions $q_i^A$, it only depends on types $\theta$.

:::{important}
In the resale subgame, the resale price does not depend on the starting positions.
:::

Alternatively, we could have solved it like this:

\begin{gather*}
\max_{q^R_i} \theta_i (q_i^A + q_i^R) - \frac{\mu}{2}(q_i^A + q_i^R)^2 - p^R q_i^R\\
\theta_i - \mu (q_i^A + q_i^R) - p^R - q_i^R \frac{\partial p^R}{\partial q_i^R} = 0
\end{gather*}

Again, we hope that price impact in the second period is constant and so we call it $\lambda^R_2 = \frac{\partial p^R}{\partial q_i^R}$.

$$ \theta_i - \mu (q_i^A + q_i^R) - p^R - q_i^R \lambda_2^R = 0 $$

Again, we can absorb the the positions $q_i^A$ into private types $\theta_i$

$$ (\theta_i - \mu q_i^A) - p^R = (\mu + \lambda_2^R) q^R_i $$

:::{seealso}
Applying, again, the result from [toy model with market power](double_auctions_market_power)
:::

$$ p^R = \bar \theta, \quad \lambda_2^R = \frac{\mu}{n-2}, \quad q^R_i = (\lambda_2^R + \mu)^{-1}(\theta_i - \mu q_i^A - p^R)$$

:::{important}
The definition of **price impact** $\lambda^R$ does not depend on what's in the denominator: $q_i$ or $q_i^R$.
:::

We can now move towards the first stage:

\begin{gather*}
\max_{q_i^A} \theta_i q_i - \frac{\mu}{2}q_i^2 - p^R (q_i - q_i^A) - p^A q_i^A\\
(\theta_i - \mu q_i)\frac{\partial q_i}{\partial q_i^A} - p^R (\frac{\partial q_i}{\partial q_i^A} - 1) - \frac{\partial p^R}{\partial q_i^A}(q_i - q_i^A) - p^A = 0\\
(\theta_i - \mu q_i - p^R)\frac{\partial q_i}{\partial q_i^A} + p^R - 0 \cdot (q_i - q_i^A) - p^A = 0
\end{gather*}

What we get is

$$ (\theta_i - \mu q_i - p^R)\frac{\lambda^R}{\mu + \lambda^R} + p^R - p^A = 0 $$

I can finally average it out

$$ (\bar \theta - p^R)\frac{\lambda^R}{\mu + \lambda^R} + p^R - p^A = 0 $$

Recalling that $ p^R = \bar \theta $ we arrive at the following result:

:::{important}
Case 1: The wholesale price coincides with the resale price.
:::

And finally, the cumulative trade is $q_i = \mu^{-1} (\theta_i - \bar \theta)$, which actually maximizes true sum of utilities:

$$ \mathcal{L} = \sum_i \theta_i q_i - \frac{\mu}{2} q_i^2 + \lambda \sum q_i \to \max_q \min_{\lambda}$$

:::{important}
Case 1: The final allocation is **efficient**.
:::

:::{warning}
Substituting (equilibrium) resale price with the (equilibrium) wholesale price is only valid because we already took the first order condition. If we did it before optimizing, that would have been a logical mistake.
:::

### Case 2: No market power in the resale

In the second stage, the optimization problem is:

\begin{gather*}
\max_{q_i} \theta_i q_i - \frac{\mu}{2}q_i^2 - p^R (q_i - q_i^A)\\
\theta_i - \mu q_i - p^R = 0\\
p^R = \bar \theta
\end{gather*}

But we assumed no market power in the resale, so the final allocation again maximizes sum of utilities:

$$ \mathcal{L} = \sum_i \theta_i q_i - \frac{\mu}{2} q_i^2 + \lambda \sum q_i \to \max_q \min_{\lambda}$$

:::{important}
Case 2: The final allocation is **efficient**.
:::

We can now move towards the first stage, but add market power:

\begin{gather*}
\max_{q_i^A} \theta_i q_i - \frac{\mu}{2}q_i^2 - p^R (q_i - q_i^A) - p^A q_i^A\\
(\theta_i - \mu q_i)\frac{\partial q_i}{\partial q_i^A} - p^R (\frac{\partial q_i}{\partial q_i^A} - 1) - \frac{\partial p^R}{\partial q_i^A}(q_i - q_i^A) - p^A - \frac{\partial p^A}{\partial q_i^A} q_i^A = 0\\
(\theta_i - \mu q_i - p^R) \times 0 + p^R - 0 \cdot (q_i - q_i^A) - p^A - \lambda^A q_i^A= 0
\end{gather*}

What we get is

$$p^R - p^A = \lambda^A q_i^A $$

Averagin this out we obtain

:::{important}
Case 2: The wholesale price coincides with the resale price.
:::

And also, somewhat unexpectedly, the wholesale market collapsed

:::{important}
Case 2: There is no trade in the wholesale.
:::

### Case 3: Market power in both periods

This is a combination of Case 1 and Case 2 really... I'll fill this in later

## Models with complex information

We will consider a model with a complex information as in [this Econometrica paper](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double auctions/ECTA_paper.pdf) and also [this old paper](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double auctions/kyle_89.pdf).

Private types $\theta|\omega$ would be distributed jointly normally with mean $\omega I_n$ and covariance matrix $C$. Fundamental value $\omega$ will be distributed normally with mean 0 and variance $\sigma^2$. That is,

$$\mathbb{V}[\theta_i] = \sigma^2 + C_{ii}$$

:::{important}
The model is called **equicommonal** if $C_{ii} = 1$ and $\sum_{j \neq i} C_{ij} = \rho$ for all $i$. The $\rho$ coefficient is called **commonality** and measures the aggregate interdependence between agents' types. This means that sum of all elements in row/column is equal to $1 + \rho$.
:::

:::{seealso}
The [interdependent utilities](double_auctions_interdependent) model would be a special case of the **equicommonal** model when off-diagonal elements of the $C$ matrix are all equal to each other.
:::

The utility of agent in this model (derived from CARA) is equal to

$$ U(\theta_i, q_i, p^{\ast}) = \mathbb{E}[\omega|\theta_i, p^{\ast}]q_i - \frac{\mu}{2 \mathbb{V}[\omega|\theta_i, p^{\ast}]} q_i^2 - p^{\ast} q_i$$

:::{warning}
We do not place $q_i$ into the information set on purpose. Whenever a variable is a choice variable (such that agents optimize over it), it is automatically non-random.
:::

We will conjecture that $\omega, \theta_i, p^{\ast}$ will be jointly normally distributed. In this case, the conditional variance is just a number, so let's absorb it into $\mu$ without loss of generality.

$$ \mathbb{V}[\omega|\theta_i, p^{\ast}] = 1 $$

The interesting bit is the conditional expectation. Without further delay we will conjecture a symmetric equilibrium and so the equilibrum price will be proportional to $\bar \theta$. Consequently,

$$ \mathbb{E}[\omega|\theta_i, p^{\ast}] = \mathbb{E}[\omega|\theta_i, \bar \theta_{-i}]$$

We already know that this conditional expectation is linear, but will it be linear for everybody in the same way given the complex structure of the covariance matrix?

Observe that the covariance matrix of $(\omega, \theta_i, \bar \theta_{-i})$ has a 3-block form:

$$ \begin{pmatrix}
\sigma^2 & \sigma^2 & \sigma^2\\
\sigma^2 & \sigma^2 + 1 & 0\\
\sigma^2 & 0 & K
\end{pmatrix}
$$

where $K$ is some constant that depends on $\rho$ but not $i$, which follows from the **equicommonality** assumption. The conditional expectation formula then tells that

$$ \mathbb{E}[\omega | \theta_i, \bar \theta_{-i}] = \mathbb{E} \omega + \sigma^2 (1, 1) \begin{pmatrix}
\sigma^2 + 1 & 0\\
0 & K
\end{pmatrix}^{-1}
(\theta_i, \bar \theta_{-i})^T
$$

And we are almost back to our [interdependent utilities](double_auctions_interdependent) model, and so our conjecture of symmetric equilibrium in linear strategies must hold. The remainder of the solution is just like all others.


## Models with a non-linear strategy

A few words about non-linearity is mentioned in this [book](
https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double_auctions/vives_book.pdf) but some very good developement can be found in [Glebkin Dissertation](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double auctions/glebkin_diss.pdf) and [his paper](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double auctions/glebkin_new.pdf).

Assume a quadratic utility again with common value $\theta$

$$U(q, \theta) = q \theta - \frac{\mu}{2} q^2$$

but this time the demands will be non-linear.


:::{important}
Models where all \theta_i are the same are called **common value** models. They can not really tell an interesting story about information, but they can be useful for other purposes.
:::

Still, we shall look for a symmetric equilibrium. Let $\Lambda(q)$ be the price impact, and $I(q)$ be the inverse demand. The equilibrium is then characterized by

- **optimality conditions** from profit maximization

$$ \theta - (\mu + \Lambda(q)) q = p $$

- **consistency of price impact** and residual curve

$$ \Lambda(q) = \frac{\partial p}{\partial q} = \frac{1}{-\frac{\partial}{\partial p} \sum_{j \neq i} q_j} = \frac{-1}{n-1} I'(q)$$

giving rise to a single ODE of the following form

:::{important}
Characteristic ODE

$$
\theta - \mu q + \frac{1}{n-1}I'(q)q = I(q)
$$

can be solved as

$$I(q) = (n-1)\int_1^{\infty} x^{-n} (\theta - \mu x q) dx + c q^{n-1}$$

and the only constant that makes economic sense is $c = 0$.
:::

Indeed, taking the integral yields

$$ I(q) = \theta - \frac{n-1}{n-2}q \mu $$

which is exactly the opposite to

$$ q(p) = \frac{n-2}{n-1} \mu^{-1} (\theta - p)$$

Unfortunately, with private values this becomes a system of ODE.

## Models with a stationary equilibrium

This is inspired mostly by [Vayanos dissertation](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double auctions/vayanos_diss.pdf) and [his paper](https://github.com/pandreyanov/grad_micro_lectures/blob/main/_assets/papers/double auctions/vayanos_main.pdf).
